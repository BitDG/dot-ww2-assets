from pathlib import Path
import hashlib,json,zipfile,shutil
B=Path(__file__).resolve().parents[1];D=B/'evidence/final';C=B/'checkpoints/Q6-final';C.mkdir(exist_ok=True)
verify=json.loads((D/'actual-render-verification.json').read_text());assert verify['status']=='PASS_ACTUAL_TEN_VIEW_RENDER_AND_UNCHANGED_CORE'
packet=C/'QF17-Q6-final-render-evidence.zip'
paths=[]
def add(p,arc):assert p.is_file(),str(p);paths.append((p,arc))
for p in sorted(D.glob('QF17-Q6-PGF-*.png')):add(p,'renders/'+p.name)
for name in ['QF17-Q6-PGF-medium.glb','QF17-Q6-PGF-medium-recipe.json','render-plan.json','actual-render-verification.json','board-composition-provenance.json']:
 add(D/name,name)
add(B/'authoring/QF17-Q6-final-PGF-review.blend','blender/QF17-Q6-final-PGF-review.blend')
for p in sorted((B/'authoring/queue-final').glob('*.receipt.json')):add(p,'mcp/'+p.name)
for name in ['Q6-final-session-initialize.json','Q6-final-runtime.json','Q6-library-restore-verification.json','Q6-final-assets-library-receipt.json']:
 add(B/'evidence'/name,'evidence/'+name)
for name in ['mcp-final-session.py','start_background_final.py','render-qf17-final-setup.py','compose-final-review-boards.py','verify-actual-final-renders.py','package-final-render-checkpoint.py']:
 add(B/'authoring'/name,'authoring/'+name)
with zipfile.ZipFile(packet,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,arc in paths:z.write(p,arc)
with zipfile.ZipFile(packet) as z:assert z.testzip() is None
for name in ['QF17-Q6-PGF-hero.png','QF17-Q6-PGF-three-view.png','QF17-Q6-PGF-six-details.png','actual-render-verification.json','render-plan.json']:shutil.copy2(D/name,C/name)
(C/'README.zh-CN.md').write_text('''# QF17 Q6 最终实渲补充阶段\n\n- 同一冻结 medium PBR GLB 真实渲染：hero、严格正交三视、六个外观细节，共十个原始视图\n- 固定 GLB SHA256：6a9afc0cbf9cf5f14241d4280bf4645ee2d80933e13f09e83de473c89a5b7575\n- Blender 4.3.2 / Cycles CPU / 192 samples，实际 MCP 回执、相机参数及最终原生 review .blend 均在证据包内\n- 两张版面仅排入真实渲染像素，没有图生图、AI补画、几何重建或材质替换\n- 属简化、非测绘、非功能的静态游戏外观重建；隐藏面是美术推测，不宣称历史高相似。没有动作片段。medium档炮口与轮胎近景仍可见分段轮廓，不作高精度复刻宣称\n- 冻结模块28件 SHA 复核未变。本增量不修改任何核心、注册、L0参考原图\n\n## 文件\n\nhero 和两张版面便于直接审阅；ZIP 收齐十个原始视图、两张版面、固定 GLB、原生 review 源、相机配置、实际 MCP 回执和作者脚本。博物馆观察照片/PDF未包含\n''')
files=[p for p in sorted(C.iterdir()) if p.name!='manifest.json']
manifest={'stage':'Q6-final-actual-PGF-renders','status':'render-evidence-complete-core-unchanged','files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'suggestedRepoPath':'modules/qf17-visual-prop/evidence/Q6-final/'+p.name} for p in files]}
(C/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'directory':str(C),'files':len(files)+1,'packetBytes':packet.stat().st_size,'packetSHA256':hashlib.sha256(packet.read_bytes()).hexdigest()}))
