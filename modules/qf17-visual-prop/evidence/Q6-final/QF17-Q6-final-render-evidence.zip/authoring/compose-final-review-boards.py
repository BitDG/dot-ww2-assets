"""Compose existing, genuine Blender render pixels into the requested review layout.
No generative editing, material changes, geometry changes, warping, or retouching.
"""
from pathlib import Path
import json,hashlib
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parents[1];D=B/'evidence/final'
expected='6a9afc0cbf9cf5f14241d4280bf4645ee2d80933e13f09e83de473c89a5b7575'
assert hashlib.sha256((D/'QF17-Q6-PGF-medium.glb').read_bytes()).hexdigest()==expected
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def f(n,b=False):return ImageFont.truetype(bold if b else font,n)
bg=(244,244,243);ink=(70,72,73);line=(190,191,189)
used=[]
def paste(board,key,box):
 p=D/f'QF17-Q6-PGF-{key}.png';im=Image.open(p).convert('RGB');im.thumbnail((box[2],box[3]),Image.Resampling.LANCZOS)
 board.paste(im,(box[0]+(box[2]-im.width)//2,box[1]+(box[3]-im.height)//2))
 used.append({'view':key,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pixels':'unaltered except uniform scale for layout'})
def text(draw,xy,s,size=25,b=False):draw.text(xy,s,font=f(size,b),fill=ink)
board=Image.new('RGB',(1800,1400),bg);draw=ImageDraw.Draw(board)
text(draw,(30,20),'QF 17-POUNDER | ACTUAL PGF GLB RENDER',42,True)
text(draw,(30,73),'Q6 / MEDIUM DETAIL / FIXED STATIC EXTERIOR',21)
paste(board,'side',(24,116,1752,655));text(draw,(35,776),'SIDE / ORTHOGRAPHIC',25)
draw.line((24,818,1776,818),fill=line,width=2)
paste(board,'top',(24,838,1190,467));text(draw,(35,1306),'TOP / STRICT 90-DEGREE ORTHOGRAPHIC',23)
draw.line((1230,838,1230,1344),fill=line,width=2)
paste(board,'front',(1245,838,531,467));text(draw,(1254,1306),'FRONT / ORTHOGRAPHIC',23)
text(draw,(35,1360),'SIMPLIFIED GAME ART / UNMEASURED / HIDDEN SURFACES ARTISTICALLY INFERRED',21)
out=D/'QF17-Q6-PGF-three-view.png';board.save(out)
board=Image.new('RGB',(1800,1250),bg);draw=ImageDraw.Draw(board)
text(draw,(24,17),'QF 17-POUNDER | ACTUAL EXTERIOR DETAIL RENDERS',36,True)
items=[('detail-wheel','01  WHEEL & LAYERED HUB'),('detail-shield','02  SHIELD LAYERS'),('detail-trails','03  DEPLOYED SPLIT TRAILS'),('detail-muzzle','04  SHALLOW SEALED MUZZLE'),('detail-carriage','05  CLOSED CARRIAGE FACADE'),('detail-tail','06  TAIL SPADES & FITTINGS')]
for i,(key,label) in enumerate(items):
 x=24+(i%3)*592;y=80+(i//3)*568
 paste(board,key,(x,y,568,506));draw.rectangle((x,y,x+568,y+549),outline=line,width=1)
 text(draw,(x+12,y+515),label,22)
text(draw,(24,1207),'SAME FROZEN GLB / NONFUNCTIONAL EXTERIOR / HIDDEN SURFACES ARTISTICALLY INFERRED',20)
board.save(D/'QF17-Q6-PGF-six-details.png')
record={'method':'Deterministic panel composition of original Blender renders; no generated or retouched pixels','fixedGLBSHA256':expected,'sources':used,'outputs':[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [out,D/'QF17-Q6-PGF-six-details.png']]}
(D/'board-composition-provenance.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
