"""Render-only staging. Imports the frozen PGF medium GLB without remodeling."""
import bpy, math, json
from mathutils import Vector
BASE='/workspace/scratch/6a4c729be230/qf17-production'
SOURCE=BASE+'/evidence/final/QF17-Q6-PGF-medium.glb'
SOURCE_SHA256='6a9afc0cbf9cf5f14241d4280bf4645ee2d80933e13f09e83de473c89a5b7575'
if bpy.data.scenes.get('QF17_Final_Actual_GLB_Review'):
 raise RuntimeError('Final review scene already exists; inspect before restarting')
scene=bpy.data.scenes.new('QF17_Final_Actual_GLB_Review');bpy.context.window.scene=scene
bpy.ops.import_scene.gltf(filepath=SOURCE)
meshes=[o for o in scene.objects if o.type=='MESH']
points=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box]
lo=Vector(tuple(min(v[i] for v in points) for i in range(3)))
hi=Vector(tuple(max(v[i] for v in points) for i in range(3)));center=(lo+hi)/2
scene['sourceGLB']=SOURCE;scene['sourceSHA256']=SOURCE_SHA256
scene['scope']='Actual frozen GLB material render; simplified nonfunctional exterior art'
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=192
scene.cycles.use_denoising=False;scene.cycles.adaptive_threshold=.012;scene.cycles.max_bounces=4
scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.render.film_transparent=False
scene.world=bpy.data.worlds.new('QF17_Final_Pale_World');scene.world.use_nodes=True
bg=next(n for n in scene.world.node_tree.nodes if n.type=='BACKGROUND')
bg.inputs['Color'].default_value=(.77,.79,.80,1);bg.inputs['Strength'].default_value=.55
scene.view_settings.view_transform='AgX';scene.view_settings.exposure=-.55
m=bpy.data.materials.new('QF17_Final_Studio_Floor');m.use_nodes=True
bs=next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
bs.inputs['Base Color'].default_value=(.83,.84,.85,1);bs.inputs['Roughness'].default_value=.85
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,lo.z-.008))
floor=bpy.context.object;floor.name='QF17_Review_Floor';floor.data.materials.append(m)
for n,loc,energy,size in [('Key',(5,-6,10),1250,7),('Fill',(-6,-2,6),900,6),('Back',(1,6,8),1200,5)]:
 data=bpy.data.lights.new('QF17_Final_'+n,'AREA');data.energy=energy;data.shape='DISK';data.size=size
 o=bpy.data.objects.new(data.name,data);scene.collection.objects.link(o);o.location=loc
 o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
data=bpy.data.cameras.new('QF17_Final_Camera');camera=bpy.data.objects.new('QF17_Final_Camera',data)
scene.collection.objects.link(camera);scene.camera=camera;data.type='ORTHO';data.clip_end=300
bpy.ops.wm.save_as_mainfile(filepath=BASE+'/authoring/QF17-Q6-final-PGF-review.blend',compress=True)
print(json.dumps({'scene':scene.name,'source':SOURCE,'sourceSHA256':SOURCE_SHA256,'boundsMin':list(lo),'boundsMax':list(hi),'assetMeshes':len(meshes),'assetMaterials':sorted({m.name for o in meshes for m in o.data.materials}),'samples':scene.cycles.samples,'denoising':False,'note':'Installed build has no OIDN; no additional software installed','saved':BASE+'/authoring/QF17-Q6-final-PGF-review.blend'}))
