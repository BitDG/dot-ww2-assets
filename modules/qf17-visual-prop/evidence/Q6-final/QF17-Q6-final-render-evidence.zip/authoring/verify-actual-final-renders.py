from pathlib import Path
from PIL import Image,ImageStat
import json,hashlib,math,datetime
B=Path(__file__).resolve().parents[1];D=B/'evidence/final';Q=B/'authoring/queue-final'
plan=json.loads((D/'render-plan.json').read_text());fixed=D/plan['fixedGLB']
assert hashlib.sha256(fixed.read_bytes()).hexdigest()==plan['fixedSHA256']
records=[]
def parsed_receipt(p):
 r=json.loads(p.read_text());assert r['result']['isError'] is False,p.name
 s=r['result']['structuredContent']['result'];assert s.startswith('Code executed successfully:'),s
 vals=[]
 for line in s.splitlines():
  try:vals.append(json.loads(line[line.index('{'):]))
  except (ValueError,json.JSONDecodeError):pass
 assert vals,p.name
 return vals[-1]
for i,v in enumerate(plan['views'],2):
 receipt=Q/f"{i:03d}-{v['view']}.receipt.json";r=parsed_receipt(receipt)
 assert r['view']==v['view'] and r['sourceSHA256']==plan['fixedSHA256']
 assert r['projection']=='ORTHO' and r['resolution']==v['resolution']
 assert r['samples']==plan['samples']
 p=D/f"QF17-Q6-PGF-{v['view']}.png";im=Image.open(p);assert list(im.size)==v['resolution'];im.verify()
 im=Image.open(p).convert('RGB');stats=ImageStat.Stat(im);assert min(stats.stddev)>10
 records.append(dict(r,fileSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),receiptSHA256=hashlib.sha256(receipt.read_bytes()).hexdigest(),pixelStddev=stats.stddev))
for axis,view in [(0,'side'),(1,'front')]:
 r=next(r for r in records if r['view']==view);delta=[r['camera'][i]-r['target'][i] for i in range(3)]
 assert all(abs(delta[i])<1e-5 for i in range(3) if i!=axis),view
r=next(r for r in records if r['view']=='top');assert max(abs(x) for x in r['rotationEuler'][:2])<1e-6
assert abs(r['rotationEuler'][2]-math.pi/2)<1e-5
assert len({r['fileSHA256'] for r in records})==10
save=parsed_receipt(Q/'012-final-save.receipt.json');assert save['assetMeshes']==24 and save['triangles']==50776
assert all(x['packed'] for x in save['packedImages'])
frozen=json.loads((B/'Q6-FROZEN-MODULE.json').read_text());M=Path(frozen['modulePath'])
for x in frozen['files']:assert hashlib.sha256((M/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
report={'status':'PASS_ACTUAL_TEN_VIEW_RENDER_AND_UNCHANGED_CORE','timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceGLB':fixed.name,'sourceSHA256':plan['fixedSHA256'],'sourceTriangles':50776,'assetMeshes':24,'nativeReviewFile':save['saved'],'nativePackedImages':save['packedImages'],'unchangedFreezeFiles':len(frozen['files']),'actualMCPReceipts':12,'originalRenderViews':records,'orthographicChecks':{'sideExactAxis':True,'topExact90Degrees':True,'frontExactAxis':True},'renderEngine':'Blender 4.3.2 Cycles CPU 192 samples; existing build has no OIDN','historicalAccuracy':'Simplified unmeasured art reconstruction; no high-similarity certification','animation':'none','noGeometryOrMaterialReplacementForRendering':True}
(D/'actual-render-verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({'status':report['status'],'actualViews':10,'unchangedFreezeFiles':28,'sourceSHA256':plan['fixedSHA256']}))
