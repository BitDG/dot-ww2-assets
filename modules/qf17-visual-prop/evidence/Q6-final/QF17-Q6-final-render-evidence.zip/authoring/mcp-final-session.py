"""Same verified process-tree lifecycle, real MCP SDK transport throughout."""
import asyncio,os,sys,json,subprocess,socket,importlib.metadata
from pathlib import Path
from datetime import timedelta
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
BASE=Path(__file__).resolve().parents[1];TOOLS=BASE.parent/'pgf-author-recovery/tools';Q=BASE/'authoring/queue-final';Q.mkdir(exist_ok=True)
async def main():
 env=os.environ.copy();env.update(PYTHONPATH=str(TOOLS/'python-packages'),BLENDER_MCP_SAFE_MODE='1',BLENDER_HOST='127.0.0.1',BLENDER_PORT='19876',DISABLE_TELEMETRY='1',BLENDER_MCP_DISABLE_TELEMETRY='1',MCP_DISABLE_TELEMETRY='1',XDG_DATA_HOME=str(TOOLS/'runtime/data'),XDG_CONFIG_HOME=str(TOOLS/'runtime/config'))
 with (BASE/'evidence/Q6-final-session-blender.log').open('w') as blog,(BASE/'evidence/Q6-final-session-server.log').open('w') as err:
  blender=subprocess.Popen(['/usr/bin/blender','-b','--factory-startup','--disable-autoexec','--python',str(BASE/'authoring/start_background_final.py')],env=env,stdout=blog,stderr=subprocess.STDOUT)
  try:
   for _ in range(200):
    if blender.poll() is not None:raise RuntimeError('Blender startup failed')
    try:
     with socket.create_connection(('127.0.0.1',19876),timeout=.1):break
    except OSError:await asyncio.sleep(.1)
   else:raise RuntimeError('Blender startup timeout')
   async with stdio_client(StdioServerParameters(command=sys.executable,args=['-m','blender_mcp.server'],env=env),errlog=err) as (read,write):
    async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=600)) as session:
     initial={'initialize':(await session.initialize()).model_dump(mode='json'),'tools':(await session.list_tools()).model_dump(mode='json'),'status':(await session.call_tool('get_addon_status',{})).model_dump(mode='json'),'scene':(await session.call_tool('get_scene_info',{})).model_dump(mode='json'),'transport':'real SDK MCP stdio and unchanged addon','safeMode':True,'telemetry':False}
     (BASE/'evidence/Q6-final-session-initialize.json').write_text(json.dumps(initial,indent=2));print('QF17_MCP_SESSION_READY',flush=True)
     while True:
      for p in sorted(Q.glob('*.request.json')):
       output=p.with_name(p.name.replace('.request.json','.receipt.json'))
       if output.exists():continue
       request=json.loads(p.read_text())
       if request['name']=='__STOP__':return
       result=await session.call_tool(request['name'],request.get('arguments',{}))
       output.write_text(json.dumps({'request':request,'result':result.model_dump(mode='json')},indent=2));print(output.name,flush=True)
      await asyncio.sleep(.5)
  finally:
   blender.terminate();blender.wait(timeout=15)
asyncio.run(main())
