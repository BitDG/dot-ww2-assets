"""Same headless lifecycle adapter as the approved K2 authoring flow."""
import bpy, importlib.util, socket, threading, time, json, os, hashlib
from pathlib import Path
ROOT=Path('/workspace/scratch/6a4c729be230/qf17-production/evidence')
ADDON=Path('/workspace/scratch/6a4c729be230/pgf-author-recovery/tools/python-packages/blender_mcp/bundled/addon.py')
assert hashlib.sha256(ADDON.read_bytes()).hexdigest()=='eb0facf69781a30e69792532087d8d41c6a14fcd323353250abe7988ee297fa5'
spec=importlib.util.spec_from_file_location('k5_blender_addon', ADDON)
addon=importlib.util.module_from_spec(spec);spec.loader.exec_module(addon)
addon.register()
for timer in (addon._addon_update_check_on_startup, addon._blendermcp_ensure_server_running):
    if bpy.app.timers.is_registered(timer): bpy.app.timers.unregister(timer)
integrations=['polyhaven','sketchfab','polypizza','hyper3d','hunyuan3d','tripo']
for name in integrations: setattr(bpy.context.scene,'blendermcp_use_'+name,False)
bpy.context.scene.blendermcp_auto_start_server=False
bpy.context.preferences.filepaths.use_scripts_auto_execute=False
server=addon.BlenderMCPServer(host='127.0.0.1',port=19876)
server.socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
server.socket.bind((server.host,server.port));server.socket.listen(5);server.running=True
bpy.types.blendermcp_server=server
server.server_thread=threading.Thread(target=server._server_loop,daemon=True)
server.server_thread.start()
report={'pid':os.getpid(),'host':server.host,'port':server.port,'blender_version':bpy.app.version_string,'addon_version':addon.bl_info['version'],'addon_protocol':addon.ADDON_PROTOCOL_VERSION,'addon_sha256':hashlib.sha256(ADDON.read_bytes()).hexdigest(),'background':True,'lifecycle_adapter':'explicit main-thread upstream queue pump','telemetry_disabled':True,'integrations':{n:False for n in integrations},'hard_timeout_seconds':21600}
(ROOT/'Q6-final-runtime.json').write_text(json.dumps(report,indent=2))
print('QF17_MCP_READY '+json.dumps(report),flush=True)
started=time.monotonic()
try:
    while server.running and time.monotonic()-started<21600:
        server._drain_command_queue();time.sleep(.02)
finally:
    server.stop()
